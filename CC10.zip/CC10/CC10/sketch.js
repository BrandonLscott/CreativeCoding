/*
    Author: Brandon Scott
    Purpose: HW 10
    Date: Nov 4th 2019
    Revised Date:
*/

var fontsize = 20;
var Fmov = -1;
var x1 = 375;
var x2 = 520;
var x3 = 450;
var y1 = 375;
var y2 = 375;
var y3 = 500;
var movement1;
var movement2;
var movement3;
var movement4;
var movement5;
var movement6;



function setup() {
  createCanvas(900,900);
    movement1=Math.floor(Math.random() * 10) / 2;
    movement2=Math.floor(Math.random() * 10) / 2;
    movement3=Math.floor(Math.random() * 10) / 2;
    movement4=Math.floor(Math.random() * 10) / 2;
    movement5=Math.floor(Math.random() * 10) / 2;
    movement6=Math.floor(Math.random() * 10) / 2;
    
}

function draw() {
background(220);

//Top Text
textSize(fontsize);
textStyle(BOLD);
fill(0)
fontsize+= Fmov;
if(fontsize >= 100){
    Fmov *=-1
;}
if(fontsize <20){
    Fmov *=-1
;}
text('Brandon Portrait', 75, 75);



textSize(40);
text('Brandon Scott',550,850);
//Face
fill(245,222,179);
    circle(450,450,450);
fill(500)
    ellipse(x1, 375, 75, 35);
    ellipse(x2, 375, 75, 35);
    arc(x3, y3, 180, 180, 0, radians(180), PIE);
fill(0);
    circle(385,y1,20);
    circle(535,y2,20);
    point(365,365);
    point(345,372);
    line(529,545,372,545)
    line(415,500,415,545)
    line(485,500,485,545)

    

fill(255,228,196);
triangle(450,415,400,450,500,450);

fill(0);
square(465,440,10);
square(430,440,10);



//x movement
if(x1>= 900){
    movement1*= -1;
}
if(x1<= 0) {
    movement1*= -1;
}
x1 = x1+ movement1;

if(x2>= 900){
    movement2*= -1;
}
if(x2<= 0) {
    movement2*= -1;
}
x2 = x2+ movement2;

//y movement
if(y1>= 900){
    movement3*= -1;
}
if(y1<= 0) {
    movement3*= -1;
}
y1 = y1+ movement3;


if(y2>= 900){
    movement4*= -1;
}
if(y2<= 0) {
    movement4*= -1;
}
y2 = y2+ movement4;



//x and y movement
if(x3>= 900){
    movement5*= -1;
}
else if(x3<= 0) {
    movement5*= -1;
}
x3 = x3 + movement5;

if(y3>= 900){
    movement5*= -1;
}
else if(y3<= 0) {
    movement5*= -1;
}
y3 += movement5;

}


