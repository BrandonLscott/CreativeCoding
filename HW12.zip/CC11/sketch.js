var x = 50;
var y = 50;
var diameter = 50;
var speed = 0;
var speedY = 500;
var speed2 = 500;
var speedY2 = 550; 
var squareX = 0;
var squareY = 0;
var mousex = 0;
var mousey = 0;
var D = 0;
function setup() 
{
  createCanvas(800, 600);
}
function draw() 
{
  background(129); // Background
  obsMove(); //Create different functions to move each of the obstacles around randomly around the screen. 
  createObs(); //Create a function that creates multiple obstacles of different sizes and colors on the screen 
  createPlayer(); //Create a function that creates a player
  playerMove(); //Create a function to move the player using the keyboard
  Ball(); //Create a function that draws the circle to the screen when pressing the mouse.
  exit(); //Create a function to generate the exit
  Game(); //If the player gets to the exit, call the “you win” function.
}
  function mouseClicked()
{
  mousex= mouseX;
  mousey= mouseY;
  D = 50;
}
function obsMove()
{ speed += random(0,3);
  speedY -= random(0,3);
  speed2 -= random(0,5);
  speedY2 -= random(0,5);
  if(speed> 500){
    speed = 0
    speedY = 500 
  }
  if(speed2 < 0){
    speed2 = 500;
    speedY2 = 550;
  }
}
function createPlayer()
{
  noStroke();
  fill(255,0,255);
  square(squareX, squareY, 30);
}
function playerMove()
{
  if(keyIsDown(LEFT_ARROW))
  {
    squareX-=10;
  }
  else if(keyIsDown(RIGHT_ARROW))
  {
    squareX+=10;
  }
  else if(keyIsDown(UP_ARROW))
  {
    squareY-=10;
  }
  else if(keyIsDown(DOWN_ARROW))
  {
    squareY+=10;
  }
}
function Ball()
{
  fill(0)
  circle(mousex,mousey,D);
}
function exit()
{fill(0);
  rect(650,590,150,10);
  textSize(30)
  text('Exit',650,575)}
function youWin()
{
  textSize(80);
    text('YOU WIN!!', 300, 400);
}
function Game()
{
  if(squareX >= 640 && squareX <800 && squareY >= 590 && squareY <= 650) {
  youWin(); //Create a function to display the “You win” message.
} else{
  textSize(12)
  text('Move the pink square to the exit',0,565)
}
}
function createObs()
{fill(236,145,150);
  circle(speed2,speedY2,30);
  fill(224, 10, 23);
  square(speed,speedY,50);}