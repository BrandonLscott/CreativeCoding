var x = 50;
var y = 50;
var diameter = 50;
var speed = 0;
var speedY = 500;
var speed2 = 500;
var speedY2 = 550; 
var squareX = 0;
var squareY = 0;
var mousex = 0;
var mousey = 0;
var D = 0;
var rectArray = [650,590,150,10];
var myXs = []; // create an array for the x coordinate
var myYs = [];
var myDiameters = []; // create array for the diameter of circles
var mov = 3.33
var mov1 = 2.57
function setup() 
{
  createCanvas(800, 600);
  // create a for loop here to create the circles
    for(var i = 0; i < 2; i++)
    {
        // get all the random numbers to create a circle
        myXs[i] = getRandomX(700);
        myYs[i] = getRandomY(500);
        myDiameters[i] = getRandomDiameter(100);
    }
}
function draw() 
{
  background(129); // Background
  createPlayer(); //Create a function that creates a player
  playerMove(); //Create a function to move the player using the keyboard
  Ball(); //Create a function that draws the circle to the screen when pressing the mouse.
  exit(); //Create a function to generate the exit
  Game(); //If the player gets to the exit, call the “you win” function.
  for(var i = 0; i < myXs.length; i++)
      {
            fill('red');
            circle(myXs[i], myYs[i], myDiameters[i]);
            fill('green');
            ellipse(myYs[i], myXs[i], myDiameters[i], 15)
            fill('blue')
            rect(myDiameters[i],myXs[i],15,17)


            if(myXs[i]>800){
              myXs[i]=1;
            }
            if(myXs[i]<0){
              myXs[i]=800;
            }
            if(myYs[i]>600){
              myYs[i]=1;
            }
            if(myYs[i]<0){
              myYs[i]=600;
            }
            myXs[i] -= mov;
            myYs[i] += mov1;
      }
}
  function mouseClicked()
{
  mousex= mouseX;
  mousey= mouseY;
  D = 50;
}
function createPlayer()
{
  noStroke();
  fill(255,0,255);
  square(squareX, squareY, 30);
}
function playerMove()
{
  if(keyIsDown(LEFT_ARROW))
  {
    squareX-=10;
  }
  else if(keyIsDown(RIGHT_ARROW))
  {
    squareX+=10;
  }
  else if(keyIsDown(UP_ARROW))
  {
    squareY-=10;
  }
  else if(keyIsDown(DOWN_ARROW))
  {
    squareY+=10;
  }
}
function Ball()
{
  fill(0)
  circle(mousex,mousey,D);
}
function exit()
{fill(0);
  rect(rectArray[0],rectArray[1],rectArray[2],rectArray[3]);
  textSize(30)
  text('Exit',650,575)}
function youWin()
{
  textSize(80);
    text('YOU WIN!!', 300, 400);
}
function Game()
{
  if(squareX >= 640 && squareX <800 && squareY >= 590 && squareY <= 650) {
  youWin(); //Create a function to display the “You win” message.
} else{
  textSize(12)
  text('Move the pink square to the exit',0,565)
}
}


  function getRandomX(x)
  {
      return Math.floor(Math.random()*x)+10;
  }

  function getRandomY(y)
  {
      return Math.floor(Math.random()*y) + 10;
  }
  function getRandomDiameter(diameter)
    {
        return Math.floor(Math.random()*diameter)+10
    }